
from django.contrib import admin
from django.urls import path
from core import views as core_views
from noticias import views as noticias_views
from django.conf import settings
 
urlpatterns = [
    path('admin/', admin.site.urls),
    path('',core_views.inicio,name='inicio'),
    path('noticias/',noticias_views.noticia,name='noticias'),
]

if settings.DEBUG:
    from django.conf.urls.static import static
    urlpatterns +=static(settings.MEDIA_URL, 
        document_root=settings.MEDIA_ROOT)