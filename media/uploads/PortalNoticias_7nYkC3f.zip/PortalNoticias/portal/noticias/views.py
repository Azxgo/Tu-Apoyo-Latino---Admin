from django.shortcuts import render
from .models import News
from django.core.paginator import Paginator

def noticia(request):
    nws=News.objects.all()
    paginator = Paginator(nws,2)
    page_number = request.GET.get("page")
    page_obj = paginator.get_page(page_number)
    return render(request,'core/noticia.html',{'nws':page_obj})
    