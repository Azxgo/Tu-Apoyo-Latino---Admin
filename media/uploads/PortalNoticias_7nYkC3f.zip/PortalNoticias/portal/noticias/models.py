from django.db import models

class News(models.Model):
    title=models.CharField(max_length=80,verbose_name="Titulo")
    description=models.TextField(verbose_name="Detalle")
    imagen=models.ImageField(upload_to="projects",verbose_name="imagen")
    created=models.DateTimeField(auto_now_add=True)
    updated=models.DateTimeField(auto_now=True)

    class Meta:
        verbose_name="Noticia"
        verbose_name_plural="Noticias"
        ordering=["-created"]

    def __str__(self):
        return self.title

